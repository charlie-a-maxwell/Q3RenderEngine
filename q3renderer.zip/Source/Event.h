/*
Based on the event system in Game Coding Complete.
I made some minor changes to things I didn't think I needed or to make the simplier.
*/


#pragma once

#include "StdHeader.h"
#include <set>


// Class that holds information on the event. Will be unique for each type of event, but the same for all events of the same type.
class EventType
{
	char * const m_name;
	unsigned int m_id;
public:
	EventType(char * const name): m_id(hashName(name)), m_name(name) {}
	static unsigned int hashName(char * const name)
	{
		// Jenkins one at a time hash
		unsigned int hash = 0;
		size_t i, key_len = strlen(name);
	 
		for (i = 0; i < key_len; i++) {
			hash += name[i];
			hash += (hash << 10);
			hash ^= (hash >> 6);
		}
		hash += (hash << 3);
		hash ^= (hash >> 11);
		hash += (hash << 15);
		return hash;
	}
	unsigned int getId() const {return m_id;}
	char * const getName() const {return m_name;}

	bool operator< (EventType const &o) const
	{
		bool t = (getId() < o.getId());
		return t;
	}

	bool operator= (EventType const &o) const
	{
		bool t = (getId() == o.getId());
		return t;
	}
};

// Base class for the events.
class Event
{
	EventType m_type;
	int m_timeIn;
	EventDataPtr m_data;
public:
	Event (char * const name, int timeIn, EventDataPtr data = EventDataPtr((IEventData *)NULL)):
	  m_type(name), m_timeIn(timeIn), m_data(data) {};
	
	  ~Event() {}
	  unsigned int getId() {return m_type.getId();}

	  // Used to get the data from the event pointer. The data is dependant on the type of event.
	  template<typename _T>
	  _T * getData() const {return reinterpret_cast<_T *>(m_data.get());}

	  char* const getName() {return m_type.getName();}
	  EventType getType() const {return m_type;}
};


// Common definitions used for the events
typedef std::set<EventType> EventTypeSet;
typedef std::pair<EventTypeSet::iterator, bool> EventTypeSetRet;
typedef std::list<EventPtr> EventQueue;
typedef std::map<unsigned int, EventListenerList> EventListenerMap;
typedef std::pair<EventListenerMap::iterator, bool> EventListenerMapRet;
typedef std::pair<unsigned int, EventListenerList> EventListenerMapEntry;


// Class used to manage the events. This is a global class that manages itself. 
class EventManager : public IEventManager
{
	EventTypeSet m_eventTypes;
	EventListenerMap m_listenerMap;
	EventQueue m_eventQueue;
	
public:
	EventManager(){};
	virtual bool addListener(EventListenerPtr const & listener, EventType const & type);
	virtual bool triggerEvent(Event const & event);
	virtual bool queueEvent(EventPtr const & event);
	virtual bool tick(unsigned int maxMS);
	virtual bool validateType(EventType const & type);
};

// Event for adding new actor based on shared pointer of the actor interface class.
class EvtData_New_Actor : public IEventData
{
public:
	shared_ptr<ActorParams> m_Params;

	EvtData_New_Actor(shared_ptr<ActorParams> p)
	{
		m_Params = p;
	}
};

class Evt_New_Actor :public Event
{
public:
	static char * const gkName;
	Evt_New_Actor(shared_ptr<ActorParams> p):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_New_Actor(p))){}
};




// Event for removing the actor of the given id.
class EvtData_Remove_Actor : public IEventData
{
public:
	ActorId m_id;

	EvtData_Remove_Actor(ActorId id):m_id(id) {}
};

class Evt_Remove_Actor :public Event
{
public:
	static char * const gkName;
	Evt_Remove_Actor(ActorId id):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Remove_Actor(id))){}
};


// Event for attemping to move an actor. The matrix is the location to move the actor to.
class EvtData_Try_Move_Actor : public IEventData
{
public:
	ActorId m_id;
	Mat4x4 m_Mat;
	float m_deltaMS;

	EvtData_Try_Move_Actor(ActorId id, Mat4x4 mat, float deltaMS):m_id(id),m_Mat(mat),m_deltaMS(deltaMS) {}
};

class Evt_Try_Move_Actor :public Event
{
public:
	static char * const gkName;
	Evt_Try_Move_Actor(ActorId id, Mat4x4 mat, float deltaMS):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Try_Move_Actor(id, mat, deltaMS))){}
};



// Event for moving an actor. The matrix is the location to move the actor to.
class EvtData_Move_Actor : public IEventData
{
public:
	ActorId m_id;
	Mat4x4 m_Mat;

	EvtData_Move_Actor(ActorId id, Mat4x4 mat):m_id(id),m_Mat(mat) {}
};

class Evt_Move_Actor :public Event
{
public:
	static char * const gkName;
	Evt_Move_Actor(ActorId id, Mat4x4 mat):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Move_Actor(id, mat))){}
};



// Event to move the camera to the given location.
class EvtData_Move_Camera : public IEventData
{
public:
	Mat4x4 m_mat;

	EvtData_Move_Camera(Mat4x4 mat):m_mat(mat) {}
};

class Evt_Move_Camera :public Event
{
public:
	static char * const gkName;
	Evt_Move_Camera(Mat4x4 m_mat):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Move_Camera(m_mat))){}
};





// Event to change the state of the game (paused, running, etc)
class EvtData_Change_GameState : public IEventData
{
public:
	GameStatus m_state;

	EvtData_Change_GameState(GameStatus state):m_state(state) {}
};

class Evt_Change_GameState :public Event
{
public:
	static char * const gkName;
	Evt_Change_GameState(GameStatus state): Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Change_GameState(state))){} 
};

// Event used to create a visual effect for the shot from a tower.
class EvtData_Shot : public IEventData
{
public:
	Vec3 m_start;
	Vec3 m_end;
	ActorId m_id;
	int m_time;
	std::string m_texture;

	EvtData_Shot(ActorId id, int time, Vec3 start, Vec3 end, std::string texture):m_start(start), m_end(end), m_id(id), m_time(time), m_texture(texture){}
};

class Evt_Shot :public Event
{
public:
	static char * const gkName;
	Evt_Shot(ActorId id, int time, Vec3 start, Vec3 end, std::string texture):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Shot(id, time, start, end, texture))) {}
};

// Event used to remove a visual effect.
class EvtData_Remove_Effect: public IEventData
{
public:
	unsigned int m_eventNum;
	EvtData_Remove_Effect(unsigned int num):m_eventNum(num) {}
};

class Evt_Remove_Effect: public Event
{
public:
	static char * const gkName;
	Evt_Remove_Effect(unsigned int num):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Remove_Effect(num))) {}
};

// Event used to remove an effect by its id.
class EvtData_Remove_Effect_By_Id: public IEventData
{
public:
	ActorId m_Id;
	EvtData_Remove_Effect_By_Id(ActorId id):m_Id(id) {}
};

class Evt_Remove_Effect_By_Id: public Event
{
public:
	static char * const gkName;
	Evt_Remove_Effect_By_Id(ActorId id):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Remove_Effect_By_Id(id))) {}
};

// Event used when the display device is created.
class EvtData_Device_Created: public IEventData
{
public:
	IDirect3DDevice9 * m_device;
	EvtData_Device_Created(IDirect3DDevice9 * device):m_device(device) {}
};
class Evt_Device_Created: public Event
{
public:
	static char * const gkName;
	Evt_Device_Created(IDirect3DDevice9 * device):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Device_Created(device))) {}
};

// Event sent to rebuild the ui. Used when the display changes or resets.
class Evt_RebuildUI: public Event
{
public:
	static char * const gkName;
	Evt_RebuildUI():Event(gkName, 0){}
};

// Event used to deal damage to an actor.
class EvtData_Damage_Actor : public IEventData
{
public:
	ActorId m_id;
	int m_damage;
	EvtData_Damage_Actor(ActorId id, int damage): m_id(id),m_damage(damage){}
};

class Evt_Damage_Actor : public Event
{
public:
	static char * const gkName;
	Evt_Damage_Actor(ActorId id, int damage): Event(gkName, 0, EventDataPtr( SAFE_NEW EvtData_Damage_Actor(id, damage))) {}
};

// Event used to apply a buff (or modifier) to a target.
class EvtData_Apply_Buff : public IEventData
{
public:
	shared_ptr<IBuff> m_buff;
	EvtData_Apply_Buff(shared_ptr<IBuff> buff): m_buff(buff) {}
};

class Evt_Apply_Buff : public Event
{
public:
	static char * const gkName;
	Evt_Apply_Buff(shared_ptr<IBuff> buff): Event(gkName, 0, EventDataPtr( SAFE_NEW EvtData_Apply_Buff(buff) ) ) {}
};

// Event to create a missle type actor to target the given id.
class EvtData_Create_Missile : public IEventData
{
public:
	ActorId m_id;
	EvtData_Create_Missile(ActorId id):m_id(id){}
};

class Evt_Create_Missile : public Event
{
public:
	static char * const gkName;
	Evt_Create_Missile(ActorId id):Event(gkName, 0 , EventDataPtr( SAFE_NEW EvtData_Create_Missile(id))) {}
};

// Event used when the right mouse button has been clicked.
class EvtData_Right_Click : public IEventData
{
public:
	Vec3 m_loc;
	EvtData_Right_Click(Vec3 l):m_loc(l) {}
};

class Evt_Left_Click : public Event
{
public:
	static char * const gkName;
	Evt_Left_Click(Vec3 l):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Right_Click(l))) {}
};

// Event for when the mouse has moved.
class EvtData_Mouse_Move : public IEventData
{
public:
	Vec3 m_pos;

	EvtData_Mouse_Move(Vec3 pos):m_pos(pos) {}
};

class Evt_Mouse_Move :public Event
{
public:
	static char * const gkName;
	Evt_Mouse_Move(Vec3 pos):Event(gkName, 0, EventDataPtr(SAFE_NEW EvtData_Mouse_Move(pos))){}
};